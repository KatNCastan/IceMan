#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include <string>
#include <vector>
#include <array>

class GraphObject;
class Actor;
class Ice;
class Iceman;

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetDir);
	virtual ~StudentWorld();

	void freeDynamicallyAllocatedData();
	void allActorsDoSomething();
	int getBarrelsRemaining();
	std::string formatText(int le, int li, int h, int sq, int g, int b, int so, int sc);
	void setDisplayText();
	void removeDeadGameObjects();
	bool isTunnel(int x, int y);
	bool isIceAt(int x, int y);
	bool removeIceInFront(int x, int y);
	void removeIce(int x, int y);

	virtual int init();
	virtual int move();
	virtual void cleanUp();

private:
	std::array<std::array<Ice*, VIEW_HEIGHT-SPRITE_HEIGHT>, VIEW_WIDTH> m_iceField;
	Iceman* m_iceman;
	int m_barrels;
};

#endif // STUDENTWORLD_H_

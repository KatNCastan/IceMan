#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

class StudentWorld;

class Actor : public GraphObject
{
private:
	StudentWorld* m_world;
	bool m_active;

protected:
	bool withinBounds();
	StudentWorld* getWorld() const;
	virtual void setDead();

public:
	Actor(StudentWorld* swp, int imageID, int startX, int startY, Direction dir, double size, unsigned int depth);
	virtual ~Actor();
	
	virtual bool isDead();
	virtual void doSomething() = 0;
};

class Ice : public Actor
{
public:
	Ice(StudentWorld* swp, int x, int y);
	virtual ~Ice();
	virtual void doSomething() override;
};

class Person : public Actor
{
private:
	int m_hitPoints;
protected:
	void setHP(int hp);
public:
	using Actor::Actor;
	virtual ~Person();

	int getHP();
	void decHP(int loss);
	virtual bool isDead() override;
	virtual void annoyed() = 0;
};

class Iceman : public Person
{
private:
	int m_unitsOfWater;
	int m_sonarCharges;
	int m_goldNuggets;

	void dig();

public:
	Iceman(StudentWorld* swp);
	virtual ~Iceman();

	int getSquirtsLeftInSquirtGun();
	int getGoldCount();
	int getSonarChargeCount();
	virtual void doSomething() override;
	virtual void annoyed() override;
};
//
//class Protester : public Actor
//{
//
//};
//
//class HardcoreProtester : public Protester
//{
//
//};
//
//class Goodie : public Actor
//{
//
//};
//
//class GoldNugget : public Goodie
//{
//
//};
//
//class Sonar : public Goodie
//{
//
//};
//
//class Oil : public Goodie
//{
//
//};
//
//class Water : public Goodie
//{
//
//};
//
//class Action : public Actor
//{
//	//void annoy()
//};
//
//class Squirt : public Action
//{
//
//};
//
//class Boulder : public Action
//{
//
//};

#endif // ACTOR_H_

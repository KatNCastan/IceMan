#include "StudentWorld.h"
#include "Actor.h"
#include <string>
#include <sstream>
#include <iomanip>
using namespace std;


GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

///////////////////////////////////////////
// StudentWorld implementations
///////////////////////////////////////////

StudentWorld::StudentWorld(std::string assetDir) : GameWorld(assetDir)
{
	m_barrels = 0;
}

StudentWorld::~StudentWorld()
{
	freeDynamicallyAllocatedData();
}

void StudentWorld::freeDynamicallyAllocatedData()
{
	delete m_iceman;
	// ..delete gameObjects...

	Ice* p = m_iceField[0][0];
	for (int i = 0; i < VIEW_WIDTH; ++i)
	{
		for (int j = 0; j < VIEW_HEIGHT - 4; ++j)
		{
			p = m_iceField[i][j];
			m_iceField[i][j] = nullptr;
			delete p;
		}
	}
}

void StudentWorld::allActorsDoSomething()
{
//	// TO DO: OTHER ACTORS NOT IMPLEMENTED
	//for each actor on the level : 
	if (m_iceman->isDead() == false)
		m_iceman->doSomething();
}

int StudentWorld::getBarrelsRemaining()
{
	return m_barrels;
}

string StudentWorld::formatText(int le, int li, int h, int sq, int g, int b, int so, int sc)
{
	ostringstream oss;
	oss << "Lvl: " << setw(2) << le << "  Lives: " << setw(1) << li << "  Hlth: " << setw(3) << h << "%"
		<< "  Wtr: " << setw(2) << sq << "  Gld: " << setw(2) << g << "  Oil Left: " << setw(2) << b
		<< "  Sonar: " << setw(2) << so << "  Scr: " << setw(6) << setfill('0') << sc;
	return oss.str();
}

void StudentWorld::setDisplayText()
{
	int level = getLevel();
	int lives = getLives();
	int health = 10 * m_iceman->getHP(); 
	int squirts = m_iceman->getSquirtsLeftInSquirtGun();
	int gold = m_iceman->getGoldCount();
	int barrelsLeft = getBarrelsRemaining();
	int sonar = m_iceman->getSonarChargeCount();
	int score = getScore();
	
	string s = formatText(level, lives, health, squirts, gold, barrelsLeft, sonar, score);
	
	setGameStatText(s); // calls our provided GameWorld::setGameStatText
}

void StudentWorld::removeDeadGameObjects()
{

}

// Determines if a tunnel should be dug at the given coordinates. Returns true if the coordinates of the Ice are within range of the tunnel
bool StudentWorld::isTunnel(int x, int y)
{
	return (x > 29 && x < 34 && y > 3 && y < VIEW_HEIGHT-SPRITE_HEIGHT);
}

// Determines if Ice is at the specified coordinates
bool StudentWorld::isIceAt(int x, int y) 
{
	// Verifies if coordinates are within ice field
	if (x >= 0 && x < VIEW_WIDTH && y >= 0 && y < VIEW_HEIGHT-SPRITE_HEIGHT)
		return m_iceField[x][y] != nullptr;
	return false;
}

// Removes 4 squares of Ice in front of Iceman, depending on his direction. Returns true if at least one square of Ice is removed
bool StudentWorld::removeIceInFront(int x, int y)
{
	bool removed = false;

	GraphObject::Direction dir = m_iceman->getDirection();
	switch (dir)
	{
	case GraphObject::left:
		for (int j = y; j <= y + 3; ++j)
		{
			if (isIceAt(x, j))
			{
				removed = true;
				removeIce(x, j);
			}
		}
		break;
	case GraphObject::right:
		for (int j = y; j <= y + 3; ++j)
		{
			if (isIceAt(x + 3, j))
			{
				removed = true;
				removeIce(x + 3, j);
			}
		}
		break;
	case GraphObject::up:
		for (int i = x; i <= x + 3; ++i)
		{
			if (isIceAt(i, y + 3))
			{
				removed = true;
				removeIce(i, y + 3);
			}
		}
		break;
	case GraphObject::down:
		for (int i = x; i <= x + 3; ++i)
		{
			if (isIceAt(i, y))
			{
				removed = true;
				removeIce(i, y);
			}
		}
		break;
	}
	return removed;
}

// Remove a single square of ice. Use isIceAt() to check valid x,y coordinates
void StudentWorld::removeIce(int x, int y)
{
	if (m_iceField[x][y] == nullptr)
		return;
	Ice* p = m_iceField[x][y];
	m_iceField[x][y] = nullptr;
	delete p;
}


int StudentWorld::init()
{
	// A. Initialize the data structures used to keep track of your game�s virtual world

	// initialize ice field
	for (int i = 0; i < VIEW_WIDTH; ++i)
	{
		for (int j = 0; j < VIEW_HEIGHT-SPRITE_HEIGHT; ++j)
		{
			if (isTunnel(i, j))
				m_iceField[i][j] = nullptr;
			else
				m_iceField[i][j] = new Ice(this, i, j);
		}
	}

	//std::vector<Actor*> gameObjects;

	// B.Construct a new oil field that meets the requirements stated in the section below (filled with Ice, Barrels of oil, Boulders, Gold Nuggets, etc.)

	// C.Allocate and insert a valid Iceman object into the game world at the proper location
	m_iceman = new Iceman(this);

	return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	// Update the Game Status Line
	setDisplayText(); // update the score/lives/level text at screen top

	// The term �Actors� refers to all Protesters, the player, Goodies,
	// Boulders, Barrels of oil, Holes, Squirts, the Exit, etc.

	// Give each Actor a chance to do something
	allActorsDoSomething();

	// Remove newly-dead actors after each tick
	removeDeadGameObjects(); // delete dead game objects

	// return the proper result
	if (m_iceman->isDead() == true)
	{
		playSound(SOUND_PLAYER_GIVE_UP);
		decLives();
		return GWSTATUS_PLAYER_DIED;
	}
		

	// If the player has collected all of the Barrels on the level, then
	// return the result that the player finished the level
	/*if (theplayerCompletedTheCurrentLevel() == true)
	{
		playSound(SOUND_FINISHED_LEVEL);
		return GWSTATUS_FINISHED_LEVEL;
	}*/

	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	freeDynamicallyAllocatedData();
}




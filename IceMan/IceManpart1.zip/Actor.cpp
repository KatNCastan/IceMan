#include "Actor.h"
#include "StudentWorld.h"

//////////////////////////////////////
// Actor implementations
//////////////////////////////////////

Actor::Actor(StudentWorld* swp, int imageID, int startX, int startY, Direction dir, double size, unsigned int depth)
	: GraphObject(imageID, startX, startY, dir, size, depth)
{
	m_world = swp;
	m_active = true;
	setVisible(true);
}

Actor::~Actor() {}

StudentWorld* Actor::getWorld() const
{
	return m_world;
}

// Check if actor will be within bounds after moving in its current direction
bool Actor::withinBounds()
{
	int x = getX();
	int y = getY();
	Direction dir = getDirection();

	bool canMove = true;

	if ((x == 0 && dir == left) || (x == VIEW_WIDTH - 4 && dir == right) || (y == VIEW_HEIGHT - 4) && dir == up || (y == 0 && dir == down))
		canMove = false;

	return canMove;
}

bool Actor::isDead()
{
	return (m_active == false);
}

void Actor::setDead()
{
	m_active = false;
}

//////////////////////////////////////////
// Ice implementations
//////////////////////////////////////////

Ice::Ice(StudentWorld* swp, int x, int y)
	: Actor(swp, IID_ICE, x, y, right, 0.25, 3) {}
Ice::~Ice() {}
void Ice::doSomething() {};

//////////////////////////////////////////
// Person implementations
//////////////////////////////////////////

Person::~Person() {}

void Person::setHP(int hp)
{
	m_hitPoints = hp;
}

int Person::getHP()
{
	return m_hitPoints;
}

void Person::decHP(int loss)
{
	if ((m_hitPoints - loss) >= 0)
		m_hitPoints -= loss;
	else
		setHP(0);
}

bool Person::isDead()
{
	if (m_hitPoints == 0 && Actor::isDead() == false)
		setDead();
	return Actor::isDead();
}

////////////////////////////////////
// Iceman implementations
////////////////////////////////////

Iceman::Iceman(StudentWorld* swp) : Person(swp, IID_PLAYER, 30, 60, right, 1.0, 0)
{
	setHP(10);
	m_unitsOfWater = 5;
	m_sonarCharges = 1;
	m_goldNuggets = 0;
}

Iceman::~Iceman() {}

void Iceman::dig()
{
	if (getWorld()->removeIceInFront(getX(), getY()) == true)
		getWorld()->playSound(SOUND_DIG);
}

int Iceman::getSquirtsLeftInSquirtGun()
{
	return m_unitsOfWater;
}

int Iceman::getGoldCount()
{
	return m_goldNuggets;
}

int Iceman::getSonarChargeCount()
{
	return m_sonarCharges;
}

void Iceman::doSomething()
{
	if (isDead())
		return;

	dig();

	int ch;
	if (getWorld()->getKey(ch) == true)
	{
		// user hit a key this tick!
		switch (ch)
		{
		case KEY_PRESS_LEFT:
			if (getDirection() != left)
			{
				setDirection(left);
			}
			else if (withinBounds())
			{
				moveTo(getX() - 1, getY());
			}
			break;
		case KEY_PRESS_RIGHT:
			if (getDirection() != right)
			{
				setDirection(right);
			}
			else if (withinBounds())
			{
				moveTo(getX() + 1, getY());
			}
			break;
		case KEY_PRESS_UP:
			if (getDirection() != up)
			{
				setDirection(up);
			}
			else if (withinBounds())
			{
				moveTo(getX(), getY() + 1);
			}
			break;
		case KEY_PRESS_DOWN:
			if (getDirection() != down)
			{
				setDirection(down);
			}
			else if (withinBounds())
			{
				moveTo(getX(), getY() - 1);
			}
			break;
		case KEY_PRESS_SPACE:
			//add a Squirt in front of the player...;
			break;
			// etc�
		case KEY_PRESS_TAB:
			//TO DO DROP NUGGET
			break;
		case KEY_PRESS_ESCAPE:
			setHP(0);
			break;

		}
	}
}

void Iceman::annoyed()
{
	decHP(2);
}


